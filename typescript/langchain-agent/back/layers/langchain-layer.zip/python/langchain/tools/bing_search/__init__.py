"""Bing Search API toolkit."""
