# flake8: noqa
from typing import Dict
from langchain.chains.constitutional_ai.models import ConstitutionalPrinciple

PRINCIPLES: Dict[str, ConstitutionalPrinciple] = {}
