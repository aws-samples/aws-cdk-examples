"""Different ways to combine documents."""
