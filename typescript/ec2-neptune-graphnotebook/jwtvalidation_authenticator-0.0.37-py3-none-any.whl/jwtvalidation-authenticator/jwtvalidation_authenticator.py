from jupyterhub.auth import Authenticator
from tornado import gen, web
import jwt
import json
import base64
import requests

from traitlets import Bool, Integer, Set, Unicode, Dict, Any, default, observe

class JWTValidationAuthenticator(Authenticator):
    aws_region = Unicode(config=True,
        help="""Unicode string indicating AWS region for the ec2 instance"""
    )

    def get(self, handler):
        auth_header_data = handler.request.headers.get("x-amzn-oidc-data", "")
        jwt_header = auth_header_data.split('.')[0]
        decoded_jwt_headers = base64.b64decode(jwt_header)
        decoded_jwt_headers = decoded_jwt_headers.decode("utf-8")
        decoded_json = json.loads(decoded_jwt_headers)
        kid = decoded_json['kid']
        url = 'https://public-keys.auth.elb.' + self.aws_region + '.amazonaws.com/' + kid
        req = requests.get(url)
        pub_key = req.text
        payload = jwt.decode(auth_header_data, pub_key, algorithms=['ES256'])
        return payload

    def _authenticate(self, handler, data):
        payload = self.get(handler)
        username = payload['email'].split('@')[0]
        self.log.info(f"username: {username}")
        self.log.info(f"allowed_users: {self.allowed_users}")
        if username in self.allowed_users:
            return username
        else:
            return None

    @gen.coroutine
    def authenticate(self, handler, data):
        return self._authenticate(handler, data)